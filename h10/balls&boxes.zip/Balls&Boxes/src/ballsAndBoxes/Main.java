package ballsAndBoxes;

public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		BallContainer box = new BallContainer(10);
		Ball b1 = new Ball("White");
		Ball b2 = new Ball("Green");
		Ball b3 = new Ball("Red");
		box.addBall(b1);
		System.out.println(box.contains(b1));
		box.addBall(b2);
		System.out.println(box.size());
		box.addBall(b3);
		System.out.println(box.size());
		box.removeBall(b3);
		System.out.println(box.size());
		box.clear();
		System.out.println(box.size());
		System.out.println(box.capacity());
		System.out.println(box.size());
	}

}
