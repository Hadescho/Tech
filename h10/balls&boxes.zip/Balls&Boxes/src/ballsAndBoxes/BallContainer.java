package ballsAndBoxes;
import java.util.LinkedList;
public class BallContainer {
	int intCapacity;
	
	LinkedList<Ball> container = new LinkedList<Ball>();
	public BallContainer(int s){
		this.container = new LinkedList<Ball>();
		this.intCapacity = s;
	}
	public void addBall (Ball b1){
		if (!container.contains(b1)&&(container.size()<intCapacity)){
			container.addLast(b1);
		}
		else{
			System.out.println("This ball is already in the container");
		}
		/**
		 * Adds a ball into the container.
		 */
	}
	
	public void removeBall(Ball b1){
		container.remove(b1);	
		/**
		 * Removes ball from the container
		 */
	}
	
	public int size(){
		return container.size() ;
		/**
		 * Return size of the container
		 */
	}
	public int capacity(){
		return intCapacity;
		/**
		 * Return size of the container
		 */
	}
	
	public void clear(){
		container.clear();
		/**
		 * Clear the container
		 */
	}
	public boolean contains(Ball b1){
		return container.contains(b1);
		/**
		 * Return true if the argument is contained in the container 
		 */
	}
}
